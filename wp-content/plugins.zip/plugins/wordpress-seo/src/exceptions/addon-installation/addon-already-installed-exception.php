<?php

namespace Yoast\WP\SEO\Exceptions\Addon_Installation;

use Exception;

/**
 * Class Addon_Already_Installed_Exception
 */
class Addon_Already_Installed_Exception extends Exception {}
