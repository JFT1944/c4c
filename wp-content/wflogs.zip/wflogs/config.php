<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:7:{s:9:"wafStatus";s:7:"enabled";s:30:"learningModeGracePeriodEnabled";i:0;s:7:"authKey";s:64:"u5-AV/nU0_R:!8*8!-cu[<k7(+|>7fZFNBI3*Eo*Euq5puy0:U)6epn%^/q;J-F?";s:7:"version";s:5:"1.1.0";s:11:"wafDisabled";b:0;s:13:"attackDataKey";i:3450;s:21:"betaThreatDefenseFeed";b:0;}